// Load current state
chrome.storage.local.get(['enabled'], (result) => {
  const enabled = result.enabled !== false;
  updateUI(enabled);
});

function updateUI(enabled) {
  const statusEl = document.getElementById('statusText');
  const btn = document.getElementById('toggleBtn');
  const statusDiv = document.getElementById('status');

  if (enabled) {
    statusEl.textContent = '🔒 LOCKED';
    statusEl.style.color = '#ff3333';
    statusDiv.classList.add('locked');
    btn.textContent = 'Unlock (Stay Disciplined)';
    btn.classList.remove('on');
  } else {
    statusEl.textContent = '🔓 UNLOCKED';
    statusEl.style.color = '#0f0';
    statusDiv.classList.remove('locked');
    btn.textContent = 'Lock Now';
    btn.classList.add('on');
  }
}

document.getElementById('toggleBtn').addEventListener('click', () => {
  chrome.storage.local.get(['enabled'], (result) => {
    const newState = result.enabled === false ? true : false;
    chrome.storage.local.set({ enabled: newState }, () => {
      updateUI(newState);
      
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          if (tab.url && !tab.url.startsWith('chrome://')) {
            chrome.tabs.reload(tab.id);
          }
        });
      });
    });
  });
});

// ========== TEST WATER POPUP ==========
document.getElementById('testWater').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      // Simple test popup
      const popup = document.createElement('div');
      popup.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 999999999;
        background: linear-gradient(135deg, #1a1a2e, #16213e);
        border: 3px solid #00d4ff;
        border-radius: 20px;
        padding: 20px;
        box-shadow: 0 0 40px rgba(0, 212, 255, 0.6);
        text-align: center;
        max-width: 350px;
        font-family: Arial;
      `;
      
      const images = [
        'https://raw.githubusercontent.com/toolsbyvipin/GRAPHIC-DESIGNING/f91b119cadc4b2d67487e88738754248ca0df36d/drink1.jpg',
        'https://raw.githubusercontent.com/toolsbyvipin/GRAPHIC-DESIGNING/f91b119cadc4b2d67487e88738754248ca0df36d/drink2.jpg',
        'https://raw.githubusercontent.com/toolsbyvipin/GRAPHIC-DESIGNING/f91b119cadc4b2d67487e88738754248ca0df36d/drink3.jpg'
      ];
      const img = images[Math.floor(Math.random() * images.length)];
      
      popup.innerHTML = `
        <img src="${img}" style="width:100%;max-width:300px;border-radius:12px;margin-bottom:15px;">
        <h2 style="color:#00d4ff;font-size:24px;margin:10px 0;">💧 PAANI PEE LO!</h2>
        <p style="color:#fff;font-size:16px;">Maharaj, 1 ghanta ho gaya!</p>
        <p style="color:#fff;font-size:16px;">Abhi paani peene ka time hai 💧</p>
        <p style="color:#888;font-size:12px;">Yeh test popup hai - 10 sec baad gayab</p>
      `;
      
      document.body.appendChild(popup);
      
      setTimeout(() => {
        popup.style.transition = 'opacity 0.5s';
        popup.style.opacity = '0';
        setTimeout(() => popup.remove(), 500);
      }, 10000);
    }
  });
});