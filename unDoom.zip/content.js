// ========== unDoom - CONTENT SCRIPT + WATER REMINDER ==========

const WHITELIST = [
  'chat.openai.com',
  'chatgpt.com',
  'notebooklm.google.com',
  'grok.com',
  'x.com',
  'gemini.google.com',
  'bard.google.com',
  'youtube.com',
  'pdf',
  'drive.google.com',
  'docs.google.com'
];

// ========== WATER REMINDER CONFIG ==========
const WATER_REMINDER_INTERVAL = 60 * 60 * 1000; // 1 ghanta = 3600000 ms
const POPUP_DURATION = 10 * 1000; // 10 second

const WATER_IMAGES = [
  'https://raw.githubusercontent.com/toolsbyvipin/GRAPHIC-DESIGNING/f91b119cadc4b2d67487e88738754248ca0df36d/drink1.jpg',
  'https://raw.githubusercontent.com/toolsbyvipin/GRAPHIC-DESIGNING/f91b119cadc4b2d67487e88738754248ca0df36d/drink2.jpg',
  'https://raw.githubusercontent.com/toolsbyvipin/GRAPHIC-DESIGNING/f91b119cadc4b2d67487e88738754248ca0df36d/drink3.jpg'
];

// ========== CHECK KARO - WHITELIST MEIN HAI? ==========
function isAllowed() {
  const host = window.location.hostname;
  return WHITELIST.some(site => host.includes(site));
}

// ========== WATER REMINDER POPUP BANAO ==========
function showWaterReminder() {
  // Random side choose karo
  const sides = ['left', 'right', 'center'];
  const side = sides[Math.floor(Math.random() * sides.length)];
  
  // Random image choose karo
  const image = WATER_IMAGES[Math.floor(Math.random() * WATER_IMAGES.length)];
  
  // Popup element banao
  const popup = document.createElement('div');
  popup.id = 'water-reminder-popup';
  
  // Side ke hisaab se style
  let positionStyle = '';
  let animationStyle = '';
  
  if (side === 'left') {
    positionStyle = 'left: 20px; top: 50%; transform: translateY(-50%);';
    animationStyle = 'slideInLeft';
  } else if (side === 'right') {
    positionStyle = 'right: 20px; top: 50%; transform: translateY(-50%);';
    animationStyle = 'slideInRight';
  } else {
    positionStyle = 'left: 50%; top: 50%; transform: translate(-50%, -50%);';
    animationStyle = 'fadeIn';
  }
  
  popup.style.cssText = `
    position: fixed;
    ${positionStyle}
    z-index: 999999999;
    background: linear-gradient(135deg, #1a1a2e, #16213e);
    border: 3px solid #00d4ff;
    border-radius: 20px;
    padding: 20px;
    box-shadow: 0 0 40px rgba(0, 212, 255, 0.6),
                0 0 80px rgba(0, 212, 255, 0.3);
    animation: ${animationStyle} 0.5s ease-out;
    text-align: center;
    max-width: 350px;
    font-family: Arial, sans-serif;
  `;
  
  popup.innerHTML = `
    <style>
      @keyframes slideInLeft {
        from { transform: translateY(-50%) translateX(-400px); opacity: 0; }
        to { transform: translateY(-50%) translateX(0); opacity: 1; }
      }
      @keyframes slideInRight {
        from { transform: translateY(-50%) translateX(400px); opacity: 0; }
        to { transform: translateY(-50%) translateX(0); opacity: 1; }
      }
      @keyframes fadeIn {
        from { opacity: 0; transform: translate(-50%, -50%) scale(0.5); }
        to { opacity: 1; transform: translate(-50%, -50%) scale(1); }
      }
      @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.05); }
      }
      @keyframes float {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-10px); }
      }
      #water-reminder-popup img {
        width: 100%;
        max-width: 300px;
        border-radius: 12px;
        margin-bottom: 15px;
        animation: float 2s ease-in-out infinite;
        box-shadow: 0 10px 30px rgba(0,0,0,0.5);
      }
      #water-reminder-popup h2 {
        color: #00d4ff;
        font-size: 24px;
        margin: 10px 0;
        text-shadow: 0 0 10px rgba(0, 212, 255, 0.8);
        animation: pulse 1.5s ease-in-out infinite;
      }
      #water-reminder-popup p {
        color: #fff;
        font-size: 16px;
        margin: 8px 0;
        line-height: 1.5;
      }
      #water-reminder-popup .emoji {
        font-size: 40px;
        display: block;
        margin: 10px 0;
      }
      #water-reminder-popup .close-btn {
        position: absolute;
        top: 10px;
        right: 15px;
        background: none;
        border: none;
        color: #ff3333;
        font-size: 24px;
        cursor: pointer;
        font-weight: bold;
        transition: transform 0.2s;
      }
      #water-reminder-popup .close-btn:hover {
        transform: scale(1.3);
      }
      #water-reminder-popup .timer-bar {
        width: 100%;
        height: 5px;
        background: rgba(255,255,255,0.2);
        border-radius: 5px;
        margin-top: 15px;
        overflow: hidden;
      }
      #water-reminder-popup .timer-fill {
        height: 100%;
        background: linear-gradient(90deg, #00d4ff, #00ff88);
        width: 100%;
        animation: countdown 10s linear forwards;
      }
      @keyframes countdown {
        from { width: 100%; }
        to { width: 0%; }
      }
    </style>
    <button class="close-btn" onclick="this.parentElement.remove()">×</button>
    <img src="${image}" alt="Drink Water" onerror="this.style.display='none'">
    <span class="emoji">💧🥤💦</span>
    <h2>PAANI PEE LO!</h2>
    <p>Maharaj, 1 ghanta ho gaya!</p>
    <p>Abhi paani peene ka time hai 💧</p>
    <p style="font-size:12px;color:#888;">Apna dimaag hydrate karo, phir padhai karo!</p>
    <div class="timer-bar">
      <div class="timer-fill"></div>
    </div>
  `;
  
  document.body.appendChild(popup);
  
  // Sound bhi bajao (optional)
  try {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    oscillator.frequency.value = 800;
    oscillator.type = 'sine';
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.5);
  } catch(e) {
    // Sound fail ho gaya toh koi baat nahi
  }
  
  // 10 second baad auto remove
  setTimeout(() => {
    if (popup && popup.parentElement) {
      popup.style.transition = 'opacity 0.5s, transform 0.5s';
      popup.style.opacity = '0';
      popup.style.transform = 'translateY(-50%) scale(0.8)';
      setTimeout(() => popup.remove(), 500);
    }
  }, POPUP_DURATION);
}

// ========== WATER REMINDER TIMER START KARO ==========
function startWaterReminder() {
  // Check karo pehle se reminder set hai ya nahi
  if (window.studyLockWaterTimer) {
    clearInterval(window.studyLockWaterTimer);
  }
  
  console.log('[unDoom] Water reminder started - 1 hour interval');
  
  // Har 1 ghante baad popup dikhao
  window.studyLockWaterTimer = setInterval(() => {
    console.log('[unDoom] Water reminder triggered!');
    showWaterReminder();
  }, WATER_REMINDER_INTERVAL);
  
  // Testing ke liye - 10 second baad bhi dikhao (comment hata sakte ho)
  // setTimeout(showWaterReminder, 10000);
}

// ========== DISCIPLINE QUOTES ==========
const UNDOOM_QUOTES = [
  "Stay Hard.",
  "You are in danger of living a life so comfortable that you will never realize your true potential.",
  "Discipline equals freedom.",
  "The obstacle is the way.",
  "Comfort is the enemy of progress.",
  "Do it now. Sometimes later becomes never.",
  "Suffer the pain of discipline, or suffer the pain of regret.",
  "What you do today can improve all your tomorrows.",
  "Motivation is garbage. Motivation comes and goes. When you're driven, whatever is in front of you will get destroyed.",
  "The mind is the athlete. The body just follows.",
  "You don't have to be extreme, just consistent.",
  "Nobody cares. Work harder.",
  "Your comfort zone will kill your dreams.",
  "Every time you don't push through the hard, you're conditioning yourself to quit.",
  "Great things never came from comfort zones.",
  "The pain you feel today is the strength you feel tomorrow.",
  "Focus is a form of self-respect.",
  "A distracted mind is a wasted mind.",
  "Small disciplines repeated daily lead to great achievements.",
  "The future depends on what you do today."
];

// ========== BLOCK CHECK ==========
if (!isAllowed()) {
  const blockedHost = window.location.hostname || 'this site';
  document.documentElement.innerHTML = `
    <html>
    <head>
      <meta charset="UTF-8">
      <title>unDoom</title>
      <style>
        * { box-sizing: border-box; }
        html, body {
          margin: 0;
          padding: 0;
          height: 100%;
          background: #05070d;
          overflow: hidden;
        }
        body {
          position: relative;
          font-family: 'Segoe UI', Arial, sans-serif;
          display: flex;
          justify-content: center;
          align-items: center;
          text-align: center;
          color: #fff;
        }

        /* animated ambient background */
        .undoom-bg {
          position: fixed;
          inset: 0;
          background:
            radial-gradient(circle at 20% 30%, rgba(0, 212, 255, 0.12), transparent 45%),
            radial-gradient(circle at 80% 70%, rgba(255, 51, 51, 0.10), transparent 45%),
            linear-gradient(135deg, #05070d, #0b0f1a 60%, #05070d);
          background-size: 200% 200%;
          animation: undoomDrift 18s ease-in-out infinite;
        }
        @keyframes undoomDrift {
          0% { background-position: 0% 0%; }
          50% { background-position: 100% 100%; }
          100% { background-position: 0% 0%; }
        }

        .undoom-particles span {
          position: fixed;
          bottom: -10px;
          display: block;
          width: 3px;
          height: 3px;
          border-radius: 50%;
          background: rgba(0, 212, 255, 0.55);
          box-shadow: 0 0 6px rgba(0, 212, 255, 0.8);
          animation: undoomFloat linear infinite;
        }
        @keyframes undoomFloat {
          0%   { transform: translateY(0) translateX(0); opacity: 0; }
          10%  { opacity: 1; }
          100% { transform: translateY(-110vh) translateX(20px); opacity: 0; }
        }

        .undoom-card {
          position: relative;
          z-index: 2;
          width: min(92vw, 620px);
          padding: 56px 44px 48px;
          border-radius: 24px;
          background: rgba(15, 18, 28, 0.72);
          border: 1px solid rgba(0, 212, 255, 0.25);
          backdrop-filter: blur(14px);
          box-shadow:
            0 0 0 1px rgba(255,255,255,0.02),
            0 30px 80px rgba(0,0,0,0.55),
            0 0 60px rgba(0, 212, 255, 0.08);
          animation: undoomRise 0.7s cubic-bezier(.2,.8,.2,1) both;
        }
        @keyframes undoomRise {
          from { opacity: 0; transform: translateY(24px) scale(0.98); }
          to   { opacity: 1; transform: translateY(0) scale(1); }
        }

        .undoom-lockwrap {
          width: 74px;
          height: 74px;
          margin: 0 auto 22px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          background: radial-gradient(circle, rgba(255,51,51,0.18), transparent 70%);
          border: 1px solid rgba(255,51,51,0.35);
          animation: undoomPulseRing 2.6s ease-in-out infinite;
        }
        @keyframes undoomPulseRing {
          0%, 100% { box-shadow: 0 0 0 0 rgba(255,51,51,0.25); }
          50% { box-shadow: 0 0 0 14px rgba(255,51,51,0); }
        }
        .undoom-lockwrap svg { width: 32px; height: 32px; }

        .undoom-brand {
          font-size: 14px;
          letter-spacing: 4px;
          text-transform: uppercase;
          color: #00d4ff;
          font-weight: 700;
          margin-bottom: 6px;
        }
        .undoom-title {
          font-size: 34px;
          font-weight: 800;
          letter-spacing: 0.5px;
          margin: 0 0 6px;
          background: linear-gradient(90deg, #ffffff, #b9d4ff 60%, #00d4ff);
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
        }
        .undoom-sub {
          font-size: 14px;
          color: #8892a6;
          margin: 0 0 30px;
        }
        .undoom-sub b { color: #ff5c5c; }

        .undoom-quote-box {
          min-height: 92px;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 0 10px;
          margin-bottom: 30px;
        }
        .undoom-quote {
          font-size: 20px;
          line-height: 1.5;
          font-weight: 600;
          color: #eef2f8;
          font-style: italic;
          animation: undoomQuoteIn 0.6s ease;
        }
        .undoom-quote::before { content: '\\201C'; color: #00d4ff; margin-right: 2px; }
        .undoom-quote::after  { content: '\\201D'; color: #00d4ff; margin-left: 2px; }
        @keyframes undoomQuoteIn {
          from { opacity: 0; transform: translateY(10px); filter: blur(4px); }
          to   { opacity: 1; transform: translateY(0); filter: blur(0); }
        }

        .undoom-progress {
          width: 100%;
          height: 3px;
          background: rgba(255,255,255,0.08);
          border-radius: 3px;
          overflow: hidden;
          margin-bottom: 28px;
        }
        .undoom-progress-fill {
          height: 100%;
          width: 0%;
          background: linear-gradient(90deg, #00d4ff, #6a5cff);
          animation: undoomProgress 6s linear infinite;
        }
        @keyframes undoomProgress {
          from { width: 0%; }
          to   { width: 100%; }
        }

        .undoom-site {
          font-size: 12px;
          color: #667;
          background: rgba(255,255,255,0.04);
          border: 1px solid rgba(255,255,255,0.06);
          padding: 8px 14px;
          border-radius: 999px;
          display: inline-block;
          margin-bottom: 22px;
          word-break: break-all;
        }
        .undoom-site span { color: #ff6b6b; font-weight: 600; }

        .undoom-allowed {
          font-size: 12px;
          color: #667a8f;
          line-height: 1.8;
        }
        .undoom-allowed b { color: #7effa3; letter-spacing: 0.5px; }
      </style>
    </head>
    <body>
      <div class="undoom-bg"></div>
      <div class="undoom-particles"></div>

      <div class="undoom-card">
        <div class="undoom-lockwrap">
          <svg viewBox="0 0 24 24" fill="none" stroke="#ff5c5c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="11" width="18" height="11" rx="2"></rect>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
          </svg>
        </div>

        <div class="undoom-brand">unDoom</div>
        <h1 class="undoom-title">Focus Mode Active</h1>
        <p class="undoom-sub">This site is <b>off-limits</b> right now.</p>

        <div class="undoom-quote-box">
          <p class="undoom-quote" id="undoomQuote"></p>
        </div>

        <div class="undoom-progress"><div class="undoom-progress-fill"></div></div>

        <div class="undoom-site">Blocked: <span>${blockedHost}</span></div>

        <div class="undoom-allowed">
          <b>ALLOWED</b> — ChatGPT · Gemini · Grok · NotebookLM · YouTube (clean) · Google Docs/Drive · PDFs
        </div>
      </div>

      <script>
        (function() {
          var quotes = ${JSON.stringify(UNDOOM_QUOTES)};
          var el = document.getElementById('undoomQuote');
          var i = Math.floor(Math.random() * quotes.length);

          function render() {
            el.style.animation = 'none';
            void el.offsetWidth;
            el.style.animation = '';
            el.textContent = quotes[i];
          }
          render();

          setInterval(function() {
            i = (i + 1) % quotes.length;
            render();
          }, 6000);

          // ambient floating particles
          var container = document.querySelector('.undoom-particles');
          for (var p = 0; p < 26; p++) {
            var dot = document.createElement('span');
            dot.style.left = (Math.random() * 100) + 'vw';
            dot.style.animationDuration = (10 + Math.random() * 14) + 's';
            dot.style.animationDelay = (Math.random() * 14) + 's';
            dot.style.opacity = (0.3 + Math.random() * 0.5).toFixed(2);
            container.appendChild(dot);
          }
        })();
      </script>
    </body>
    </html>
  `;
  throw new Error('Blocked by unDoom');
}

// ========== YOUTUBE CLEANUP ==========
if (window.location.hostname.includes('youtube.com')) {
  
  console.log('[unDoom] YouTube detected - cleaning...');

  if (window.location.pathname.startsWith('/shorts')) {
    window.location.href = 'https://www.youtube.com/';
  }

  const removeElements = () => {
    const selectors = [
      'ytd-reel-shelf-renderer',
      'ytd-rich-shelf-renderer[is-shorts]',
      'ytd-shorts',
      'a[href="/shorts"]',
      'ytd-guide-entry-renderer[title="Shorts"]',
      'ytd-mini-guide-entry-renderer[title="Shorts"]',
      '#secondary',
      '#related',
      'ytd-watch-next-secondary-results-renderer',
      'ytd-comments',
      '#comments',
      'ytd-live-chat-frame',
      '#chat',
      'ytd-guide-renderer',
      '#guide',
      'ytd-mini-guide-renderer',
      '#masthead-ad',
      'ytd-banner-promo-renderer',
      'ytd-statement-banner-renderer',
      '#player-ads',
      'ytd-display-ad-renderer',
      'ytd-promoted-sparkles-web-renderer',
      'ytd-post-renderer',
      'ytd-backstage-post-thread-renderer',
      '.ytp-ce-element',
      '.ytp-endscreen-content',
      '#notification-button',
      'ytd-feed-filter-chip-bar-renderer',
      '#chips-wrapper'
    ];

    selectors.forEach(sel => {
      document.querySelectorAll(sel).forEach(el => {
        el.style.display = 'none';
        el.remove();
      });
    });
  };

  const blankHomepage = () => {
    if (window.location.pathname === '/' || window.location.pathname === '/feed/subscriptions') {
      const browse = document.querySelector('ytd-browse');
      if (browse) {
        browse.innerHTML = `
          <div style="
            display:flex;
            justify-content:center;
            align-items:center;
            height:100vh;
            background:#0f0f0f;
            color:#fff;
            font-size:28px;
            font-family:Arial;
            flex-direction:column;
          ">
            <div style="font-size:80px;">🔒</div>
            <div>unDoom Active</div>
            <div style="font-size:16px;color:#888;margin-top:20px;">
              Search bar se topic search karo aur padho
            </div>
          </div>
        `;
      }
    }
  };

  const focusSearch = () => {
    const searchBar = document.querySelector('input#search');
    if (searchBar && window.location.pathname === '/') {
      searchBar.focus();
    }
  };

  const runCleanup = () => {
    removeElements();
    blankHomepage();
    focusSearch();
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', runCleanup);
  } else {
    runCleanup();
  }

  const observer = new MutationObserver(() => {
    removeElements();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      setTimeout(runCleanup, 500);
    }
  }).observe(document, { subtree: true, childList: true });

  console.log('[unDoom] YouTube cleaned! 🔒');
}

// ========== WATER REMINDER START KARO (Sabhi Allowed Sites Pe) ==========
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', startWaterReminder);
} else {
  startWaterReminder();
}

// ========== TAB VISIBILITY CHANGE - Timer Reset ==========
// Agar user tab switch karta hai toh timer reset ho jaye
let lastVisibleTime = Date.now();
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    const awayTime = Date.now() - lastVisibleTime;
    if (awayTime > WATER_REMINDER_INTERVAL) {
      showWaterReminder();
    }
    lastVisibleTime = Date.now();
  }
});

console.log('[unDoom] All systems active! 💧🔒');