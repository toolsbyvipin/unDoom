const params = new URLSearchParams(window.location.search);
const from = params.get('from');
if (from) {
  document.getElementById('fromUrl').textContent = from;
}
