// ========== unDoom BACKGROUND SERVICE WORKER ==========
// Owns the "SITE LOCK" feature: when masterEnabled is true, every site
// EXCEPT the allowed list gets redirected to blocked.html. Turning the
// master switch off removes the rules instantly and every site opens again.

const SITE_LOCK_RULE_ALLOW_ID = 5001;
const SITE_LOCK_RULE_BLOCK_ID = 5002;

const DEFAULT_ALLOWED_DOMAINS = [
  // YouTube
  'youtube.com', 'www.youtube.com', 'm.youtube.com', 'youtu.be', 'youtubei.googleapis.com',
  // Telegram
  'web.telegram.org', 'telegram.org',
  // ChatGPT
  'chatgpt.com', 'chat.openai.com', 'openai.com',
  // NotebookLM
  'notebooklm.google.com',
  // Grok
  'grok.com', 'x.ai',
  // Gemini
  'gemini.google.com'
];

async function getState() {
  const { undoom } = await chrome.storage.local.get(['undoom']);
  return undoom || null;
}

async function applySiteLock(state) {
  const siteLockEnabled = !(state && state.siteLock && state.siteLock.enabled === false);
  const masterOn = !!(state && state.masterEnabled) && siteLockEnabled;
  const allowed =
    (state && state.siteLock && Array.isArray(state.siteLock.allowedDomains) && state.siteLock.allowedDomains.length
      ? state.siteLock.allowedDomains
      : DEFAULT_ALLOWED_DOMAINS);

  const removeRuleIds = [SITE_LOCK_RULE_ALLOW_ID, SITE_LOCK_RULE_BLOCK_ID];

  if (!masterOn) {
    // Focus mode OFF -> lift every web restriction immediately.
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds }).catch(() => {});
    return;
  }

  const blockedPageUrl = chrome.runtime.getURL('blocked.html');

  const addRules = [
    {
      id: SITE_LOCK_RULE_ALLOW_ID,
      priority: 100,
      action: { type: 'allow' },
      condition: {
        requestDomains: allowed,
        resourceTypes: ['main_frame', 'sub_frame']
      }
    },
    {
      id: SITE_LOCK_RULE_BLOCK_ID,
      priority: 1,
      action: {
        type: 'redirect',
        redirect: { regexSubstitution: blockedPageUrl + '?from=\\0' }
      },
      condition: {
        regexFilter: '^https?://.*',
        resourceTypes: ['main_frame']
      }
    }
  ];

  await chrome.declarativeNetRequest
    .updateDynamicRules({ removeRuleIds, addRules })
    .catch((err) => console.warn('[unDoom] site lock rule error', err));
}

chrome.runtime.onInstalled.addListener(async () => {
  applySiteLock(await getState());
});

chrome.runtime.onStartup.addListener(async () => {
  applySiteLock(await getState());
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes.undoom) return;
  const oldV = changes.undoom.oldValue;
  const newV = changes.undoom.newValue;
  // Only re-apply when something relevant actually changed (avoid needless work on every stat tick).
  const oldMaster = !!(oldV && oldV.masterEnabled) && !(oldV && oldV.siteLock && oldV.siteLock.enabled === false);
  const newMaster = !!(newV && newV.masterEnabled) && !(newV && newV.siteLock && newV.siteLock.enabled === false);
  const oldDomains = JSON.stringify(oldV && oldV.siteLock && oldV.siteLock.allowedDomains);
  const newDomains = JSON.stringify(newV && newV.siteLock && newV.siteLock.allowedDomains);
  if (oldMaster !== newMaster || oldDomains !== newDomains) {
    applySiteLock(newV);
  }
});
