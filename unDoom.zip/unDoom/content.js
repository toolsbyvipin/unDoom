// ========== unDoom - CONTENT SCRIPT ==========
// Sirf block page. Telegram/YouTube/AI alag files mein.

const WHITELIST = [
  'chat.openai.com',
  'chatgpt.com',
  'notebooklm.google.com',
  'grok.com',
  'x.com',
  'gemini.google.com',
  'bard.google.com',
  'youtube.com',
  'web.telegram.org',
  'pdf',
  'drive.google.com',
  'docs.google.com'
];

function isAllowed() {
  const host = window.location.hostname;
  return WHITELIST.some(site => host.includes(site));
}

// ========== SKIP TELEGRAM ==========
if (window.location.hostname.includes('web.telegram.org')) {
  console.log('[unDoom] Telegram - skip (handled by telegram-readonly.js)');
  // Kuch mat karo — telegram-readonly.js handle karega
} else {
  // ========== MASTER CHECK + BLOCK PAGE ==========
  chrome.storage.local.get(['undoom'], (result) => {
    const state = result.undoom || {};
    const masterEnabled = state.masterEnabled === true;

    if (!masterEnabled) {
      console.log('[unDoom] Master OFF');
      return;
    }

    // Skip YouTube
    if (window.location.hostname.includes('youtube.com')) {
      console.log('[unDoom] YouTube - skip');
      return;
    }

    // Skip AI sites
    const aiSites = [
      'chatgpt.com',
      'chat.openai.com',
      'notebooklm.google.com',
      'grok.com',
      'gemini.google.com'
    ];
    if (aiSites.some(site => window.location.hostname.includes(site))) {
      console.log('[unDoom] AI site - skip');
      return;
    }

    // ========== BLOCK PAGE ==========
    if (!isAllowed()) {
      const blockedUrl = chrome.runtime.getURL('blocked.html') +
        '?from=' + encodeURIComponent(window.location.href);
      window.location.href = blockedUrl;
      return;
    }
  });
}

console.log('[unDoom] content.js loaded');