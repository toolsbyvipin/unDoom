// ========== unDoom - CONTENT SCRIPT ==========

const WHITELIST = [
  'chat.openai.com',
  'chatgpt.com',
  'notebooklm.google.com',
  'grok.com',
  'x.com',
  'gemini.google.com',
  'bard.google.com',
  'youtube.com',
  'web.telegram.org',
  'pdf',
  'drive.google.com',
  'docs.google.com'
];

function isAllowed() {
  const host = window.location.hostname;
  return WHITELIST.some(site => host.includes(site));
}

// ========== MASTER CHECK ==========
chrome.storage.local.get(['undoom'], (result) => {
  const state = result.undoom || {};
  const masterEnabled = state.masterEnabled === true;

  if (!masterEnabled) {
    console.log('[unDoom] Master OFF');
    return;
  }

  // ═══════════════════════════════════════════════════════════
  // STEP 1: TELEGRAM - READ-ONLY (BLOCK PAGE SE PEHLE)
  // ═══════════════════════════════════════════════════════════
  if (window.location.hostname.includes('web.telegram.org')) {
    console.log('[unDoom] Telegram - read-only mode');

    const disableInput = () => {
      // Message input container
      const inputSelectors = [
        '.input-message-container',
        '.chat-input',
        '.composer',
        '[contenteditable="true"]'
      ];

      inputSelectors.forEach(sel => {
        document.querySelectorAll(sel).forEach(el => {
          el.setAttribute('contenteditable', 'false');
          el.style.pointerEvents = 'none';
          el.style.opacity = '0.3';
          el.style.cursor = 'not-allowed';
        });
      });

      // Send button
      document.querySelectorAll('.btn-send, button[type="submit"]').forEach(el => {
        el.disabled = true;
        el.style.opacity = '0.3';
        el.style.cursor = 'not-allowed';
      });

      // Banner
      if (!document.getElementById('undoom-readonly-banner')) {
        const banner = document.createElement('div');
        banner.id = 'undoom-readonly-banner';
        banner.style.cssText = `
          position: fixed;
          top: 0; left: 0; right: 0;
          background: linear-gradient(90deg, rgba(255,184,77,0.15), rgba(255,184,77,0.05));
          border-bottom: 1px solid rgba(255,184,77,0.3);
          color: #FFB84D;
          font-family: Consolas, monospace;
          font-size: 11px;
          letter-spacing: 1px;
          padding: 6px 16px;
          text-align: center;
          z-index: 999999;
          pointer-events: none;
        `;
        banner.textContent = '⚠ READ-ONLY MODE ACTIVE — Sending messages is disabled';
        document.body.appendChild(banner);
      }
    };

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', disableInput);
    } else {
      disableInput();
    }

    new MutationObserver(disableInput).observe(document.body, {
      childList: true,
      subtree: true
    });

    // Telegram ke liye yahin ruk jao — block page mat dikhao
    return;
  }

  // ═══════════════════════════════════════════════════════════
  // STEP 2: BLOCK PAGE (Telegram ke baad)
  // ═══════════════════════════════════════════════════════════
  if (!isAllowed()) {
    const blockedHost = window.location.hostname || 'this site';
    document.documentElement.innerHTML = `
      <html>
      <head>
        <meta charset="UTF-8">
        <title>unDoom</title>
        <style>
          body {
            margin: 0; height: 100vh; background: #05070d;
            color: #fff; font-family: Arial, sans-serif;
            display: flex; justify-content: center; align-items: center;
            text-align: center;
          }
          .card {
            padding: 40px; border-radius: 20px;
            background: rgba(15, 18, 28, 0.9);
            border: 1px solid rgba(0, 212, 255, 0.3);
            max-width: 500px;
          }
          .lock { font-size: 80px; margin-bottom: 20px; }
          h1 { color: #00d4ff; font-size: 28px; margin: 10px 0; }
          p { color: #8892a6; font-size: 14px; line-height: 1.6; }
          .blocked { color: #ff5c5c; font-weight: bold; }
        </style>
      </head>
      <body>
        <div class="card">
          <div class="lock">🔒</div>
          <h1>unDoom Active</h1>
          <p>This site is <span class="blocked">off-limits</span> right now.</p>
          <p>Blocked: <b>${blockedHost}</b></p>
          <p style="color:#00ff88;margin-top:20px;">Allowed: ChatGPT, Gemini, Grok, NotebookLM, YouTube, Telegram, PDFs</p>
        </div>
      </body>
      </html>
    `;
    return;
  }

  // ═══════════════════════════════════════════════════════════
  // STEP 3: YOUTUBE CLEANUP
  // ═══════════════════════════════════════════════════════════
  if (window.location.hostname.includes('youtube.com')) {
    console.log('[unDoom] YouTube detected');

    if (window.location.pathname.startsWith('/shorts')) {
      window.location.href = 'https://www.youtube.com/';
      return;
    }

    const removeElements = () => {
      const selectors = [
        'ytd-reel-shelf-renderer',
        'ytd-rich-shelf-renderer[is-shorts]',
        'ytd-shorts',
        'a[href="/shorts"]',
        '#secondary',
        '#related',
        'ytd-comments',
        '#comments',
        'ytd-live-chat-frame',
        '#chat',
        'ytd-guide-renderer',
        '#guide',
        '#masthead-ad',
        'ytd-display-ad-renderer',
        '.ytp-ce-element',
        '.ytp-endscreen-content',
        '#notification-button'
      ];
      selectors.forEach(sel => {
        document.querySelectorAll(sel).forEach(el => el.remove());
      });
    };

    const blankHomepage = () => {
      if (window.location.pathname === '/') {
        const browse = document.querySelector('ytd-browse');
        if (browse) {
          browse.innerHTML = `
            <div style="display:flex;justify-content:center;align-items:center;height:100vh;background:#0f0f0f;color:#fff;font-size:28px;font-family:Arial;flex-direction:column;">
              <div style="font-size:80px;">🔒</div>
              <div>unDoom Active</div>
              <div style="font-size:16px;color:#888;margin-top:20px;">Search bar se topic search karo</div>
            </div>
          `;
        }
      }
    };

    const runCleanup = () => {
      removeElements();
      blankHomepage();
    };

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', runCleanup);
    } else {
      runCleanup();
    }

    new MutationObserver(removeElements).observe(document.body, {
      childList: true,
      subtree: true
    });
  }
});

// ========== STORAGE CHANGE ==========
chrome.storage.onChanged.addListener((changes) => {
  if (changes.undoom && window.location.hostname.includes('web.telegram.org')) {
    location.reload();
  }
});

console.log('[unDoom] All systems active!');