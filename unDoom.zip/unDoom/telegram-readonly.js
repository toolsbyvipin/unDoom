// ========== unDoom - TELEGRAM READ-ONLY ==========
// Sirf master ON hone pe active

(function() {
  console.log('[unDoom] Telegram readonly loaded');

  const BANNER_ID = 'undoom-readonly-banner';
  const STYLE_ID = 'undoom-readonly-style';

  const HIDE_SELECTORS = [
    '.input-message-container',
    '.chat-input',
    '.composer',
    '.btn-send',
    '.btn-icon'
  ];

  // ========== ENABLE READ-ONLY ==========
  function enableReadOnly() {
    // Inject the hiding rules ourselves, only while master is ON.
    if (!document.getElementById(STYLE_ID)) {
      const style = document.createElement('style');
      style.id = STYLE_ID;
      style.textContent = HIDE_SELECTORS.map(sel => `${sel} { display: none !important; }`).join('\n');
      (document.head || document.documentElement).appendChild(style);
    }

    if (!document.body) return;

    // Banner
    if (!document.getElementById(BANNER_ID)) {
      const banner = document.createElement('div');
      banner.id = BANNER_ID;
      banner.style.cssText = `
        position: fixed;
        top: 0; left: 0; right: 0;
        background: linear-gradient(90deg, rgba(255,184,77,0.15), rgba(255,184,77,0.05));
        border-bottom: 1px solid rgba(255,184,77,0.3);
        color: #FFB84D;
        font-family: Consolas, monospace;
        font-size: 11px;
        letter-spacing: 1px;
        padding: 6px 16px;
        text-align: center;
        z-index: 999999;
        pointer-events: none;
      `;
      banner.textContent = '⚠ READ-ONLY MODE ACTIVE — Sending messages is disabled';
      document.body.appendChild(banner);
    }
  }

  // ========== DISABLE READ-ONLY ==========
  function disableReadOnly() {
    const style = document.getElementById(STYLE_ID);
    if (style) style.remove();

    const banner = document.getElementById(BANNER_ID);
    if (banner) banner.remove();
  }

  // ========== APPLY STATE ==========
  function applyState() {
    chrome.storage.local.get(['undoom'], (result) => {
      const state = result.undoom || {};
      const masterEnabled = state.masterEnabled === true;

      if (masterEnabled) {
        console.log('[unDoom] Master ON - read-only');
        enableReadOnly();
      } else {
        console.log('[unDoom] Master OFF - normal');
        disableReadOnly();
      }
    });
  }

  // ========== INITIAL ==========
  // Apply right away (handles the style-injection part even pre-body),
  // then again once the DOM is ready (handles the banner, which needs body).
  applyState();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyState);
  }

  // ========== WATCH DYNAMIC (only once body exists) ==========
  function startObserving() {
    if (!document.body) {
      document.addEventListener('DOMContentLoaded', startObserving, { once: true });
      return;
    }
    new MutationObserver(() => {
      chrome.storage.local.get(['undoom'], (result) => {
        const state = result.undoom || {};
        if (state.masterEnabled === true) {
          enableReadOnly();
        }
      });
    }).observe(document.body, {
      childList: true,
      subtree: true
    });
  }
  startObserving();

  // ========== STORAGE CHANGE ==========
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.undoom) {
      const newState = changes.undoom.newValue || {};
      if (newState.masterEnabled === true) {
        enableReadOnly();
      } else {
        disableReadOnly();
      }
    }
  });

})();
