// ========== unDoom — TELEGRAM PROTOCOL ==========
// Handles: story/discovery cleanup (existing feature) + READ-ONLY MODE.
// Everything here is gated by live state, so flipping the master switch OFF
// lifts every restriction immediately (chat becomes fully usable again)
// without needing a page reload.

(function () {
  if (!window.location.hostname.includes('web.telegram.org')) return;

  let state = null;

  function loadState(cb) {
    chrome.storage.local.get(['undoom'], (r) => cb(r.undoom || null));
  }

  // ---------- feature flags -> <html> classes (CSS reacts to these) ----------
  function applyFlags() {
    const masterOn = !!(state && state.masterEnabled);
    const tg = (state && state.telegram) || {};
    const html = document.documentElement;

    html.classList.toggle('undoom-tg-active', masterOn && tg.enabled !== false);
    html.classList.toggle('undoom-hide-stories', masterOn && tg.hideStories !== false);
    html.classList.toggle('undoom-hide-suggested', masterOn && tg.hideSuggestedChannels !== false);
    html.classList.toggle('undoom-reduce-discovery', masterOn && tg.reduceDiscovery !== false);

    // READ-ONLY MODE is tied straight to the master switch: focus ON -> can't
    // send messages, focus OFF -> chat mode restored, exactly as requested.
    const readOnlyOn = masterOn && tg.enabled !== false;
    html.classList.toggle('undoom-readonly', readOnlyOn);
    readOnlyActive = readOnlyOn;
    // Optional narrower scope: only lock group chats, leave DMs free.
    groupOnlyScope = !!tg.readOnlyGroupsOnly;

    toggleBanner(readOnlyOn);
  }

  loadState((s) => { state = s; applyFlags(); startCleanupLoop(); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.undoom) return;
    state = changes.undoom.newValue;
    applyFlags();
  });

  // ========== DOM CLEANUP (stories / suggested channels / discovery) ==========
  function removeTgElements() {
    const html = document.documentElement;
    if (html.classList.contains('undoom-hide-stories')) {
      document.querySelectorAll('.stories-list, .Story, [class*="StoryRibbon" i]').forEach((el) => el.remove());
    }
    if (html.classList.contains('undoom-hide-suggested')) {
      document.querySelectorAll('.suggested-channels, [class*="suggested" i]').forEach((el) => el.remove());
    }
    if (html.classList.contains('undoom-reduce-discovery')) {
      document.querySelectorAll('.discover, .folders-tabs, [class*="discover" i]').forEach((el) => el.remove());
    }
  }

  function startCleanupLoop() {
    const run = () => removeTgElements();
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', run);
    } else {
      run();
    }
    new MutationObserver(run).observe(document.documentElement, { childList: true, subtree: true });
  }

  // ========== READ-ONLY MODE ==========
  // Two layers, so it survives Telegram's frequent frontend rewrites (WebK vs WebA):
  //   1. CSS visually dims/locks the composer (see telegram.css, .undoom-readonly)
  //   2. JS hard-blocks Enter-to-send and the send button, and disables any
  //      contenteditable message box it finds — this is the layer that
  //      actually stops a message from going out even if a selector in the
  //      CSS file goes stale after a Telegram redesign.

  let readOnlyActive = false;
  let groupOnlyScope = false;

  function isGroupChatOpen() {
    // Best-effort heuristics across Telegram Web's UI versions. If none of
    // these match we simply can't tell -> caller should treat as "unknown"
    // and fall back to locking everything (safer default).
    const subtitle = document.querySelector(
      '.ChatInfo .subtitle, .chat-info .subtitle, .Chat-subtitle, #Chat .info .status, .chat-status'
    );
    if (subtitle && /\bmembers?\b|\bsubscribers?\b/i.test(subtitle.textContent || '')) return true;
    const groupIcon = document.querySelector('[class*="group" i][class*="icon" i]');
    if (groupIcon) return true;
    return null; // unknown
  }

  function shouldBlockRightNow() {
    if (!readOnlyActive) return false;
    if (!groupOnlyScope) return true;
    const isGroup = isGroupChatOpen();
    return isGroup !== false; // unknown -> block to be safe
  }

  function isComposerElement(el) {
    if (!el) return false;
    if (el.isContentEditable) return true;
    const tag = el.tagName;
    if (tag === 'TEXTAREA') return true;
    if (tag === 'INPUT' && (el.type === 'text' || el.type === 'search')) {
      // Skip Telegram's top search bar — only treat message-area inputs as composer.
      return !!el.closest('footer, .composer, [class*="Composer" i], [class*="input-message" i]');
    }
    return false;
  }

  function isSendButton(el) {
    if (!el) return false;
    const btn = el.closest('button, [role="button"]');
    if (!btn) return false;
    const label = (btn.getAttribute('aria-label') || btn.title || '').toLowerCase();
    if (/send/.test(label)) return true;
    if (btn.className && /send/i.test(String(btn.className))) return true;
    if (btn.querySelector('[class*="Send" i], [class*="send-icon" i]')) return true;
    return false;
  }

  function showToast(msg) {
    let toast = document.getElementById('undoom-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'undoom-toast';
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => toast.classList.remove('show'), 2200);
  }

  function toggleBanner(show) {
    let banner = document.getElementById('undoom-readonly-banner');
    if (show) {
      if (!banner) {
        banner = document.createElement('div');
        banner.id = 'undoom-readonly-banner';
        banner.textContent = '🔒 READ-ONLY MODE — unDoom Focus Protocol (turn off focus to chat again)';
        document.body.appendChild(banner);
      }
    } else if (banner) {
      banner.remove();
    }
  }

  // Capture-phase listeners = we see the event before Telegram's own JS does.
  // e.isTrusted guards against our own synthetic events (there aren't any
  // here, but it's the standard safety net if this file is extended later).
  document.addEventListener(
    'keydown',
    (e) => {
      if (!e.isTrusted) return;
      if (!shouldBlockRightNow()) return;
      if (e.key !== 'Enter' || e.shiftKey || e.ctrlKey || e.metaKey) return;
      if (!isComposerElement(e.target)) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      showToast('Read-only mode — sending is disabled during focus.');
    },
    true
  );

  document.addEventListener(
    'click',
    (e) => {
      if (!e.isTrusted) return;
      if (!shouldBlockRightNow()) return;
      if (!isSendButton(e.target)) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      showToast('Read-only mode — sending is disabled during focus.');
    },
    true
  );

  // Belt-and-braces: actively disable any composer box it finds while active.
  function lockComposers() {
    if (!shouldBlockRightNow()) return;
    document
      .querySelectorAll('div[contenteditable="true"], div[contenteditable=""]')
      .forEach((el) => {
        if (el.closest('footer, .composer, [class*="Composer" i], [class*="input-message" i]') || el.isContentEditable) {
          el.setAttribute('contenteditable', 'false');
          el.classList.add('undoom-locked-composer');
        }
      });
  }
  setInterval(lockComposers, 1000);
})();
