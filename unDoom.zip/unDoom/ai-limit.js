// ========== unDoom — AI RESPONSE LIMIT ==========
// While focus mode is ON, every message you send to ChatGPT / Gemini / Grok /
// NotebookLM gets a word cap enforced: if you ask for "600 words" it's
// rewritten down to the cap (default 100), and if you didn't mention a
// length at all, an instruction is appended so the model keeps it short.
// Turning focus mode OFF removes this instantly — nothing is modified.
//
// NOTE: these are all fast-moving single-page apps and their DOM/selectors
// change over time. The selector lists below are the current best-guess
// for each site; if one stops matching, add the new selector to the
// relevant array — everything else in this file stays the same.

(function () {
  const host = window.location.hostname;

  const COMPOSER_SELECTORS = [
    '#prompt-textarea',                 // ChatGPT
    'div[contenteditable="true"][data-testid*="prompt" i]',
    'rich-textarea .ql-editor',         // Gemini
    'div.ql-editor[contenteditable="true"]',
    'textarea[aria-label*="message" i]',// Grok / generic
    'textarea[data-testid*="prompt" i]',
    '.ProseMirror[contenteditable="true"]', // NotebookLM / generic ProseMirror
    'div[contenteditable="true"]'       // last-resort fallback
  ];

  const SEND_BUTTON_SELECTORS = [
    'button[data-testid="send-button"]',
    'button[aria-label*="send" i]',
    'button[aria-label*="submit" i]',
    'button.send-button'
  ];

  let state = null;

  function loadState(cb) {
    chrome.storage.local.get(['undoom'], (r) => cb(r.undoom || null));
  }
  loadState((s) => { state = s; });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.undoom) return;
    state = changes.undoom.newValue;
  });

  function limitEnabled() {
    return !!(state && state.masterEnabled && state.aiLimit && state.aiLimit.enabled !== false);
  }

  function maxWords() {
    const n = state && state.aiLimit && state.aiLimit.maxWords;
    return Number.isFinite(n) && n > 0 ? n : 100;
  }

  function findComposer(fromEl) {
    if (fromEl && isComposer(fromEl)) return fromEl;
    for (const sel of COMPOSER_SELECTORS) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  function isComposer(el) {
    if (!el) return false;
    if (el.isContentEditable) return true;
    return el.tagName === 'TEXTAREA';
  }

  function getText(el) {
    return el.isContentEditable ? el.innerText : el.value;
  }

  function applyWordLimit(text, cap) {
    let modified = text;
    // If the user explicitly asked for a longer piece, cap the requested number.
    modified = modified.replace(/(\d{2,5})(\s*-?\s*)(words?)/gi, (m, num, sep, word) => {
      const n = parseInt(num, 10);
      return n > cap ? `${cap}${sep}${word}` : m;
    });
    const alreadyInstructed = /\b(word|words)\b.*\b(limit|or (less|fewer)|max(imum)?)\b/i.test(modified);
    if (!alreadyInstructed) {
      modified = modified.replace(/\s+$/, '') + `\n\n(Please keep your response to ${cap} words or fewer.)`;
    }
    return modified;
  }

  function setComposerText(el, text) {
    el.focus();
    document.execCommand('selectAll', false, null);
    const inserted = document.execCommand('insertText', false, text);
    if (!inserted) {
      // Fallback for editors execCommand doesn't reach.
      if (el.isContentEditable) {
        el.innerText = text;
      } else {
        el.value = text;
      }
      el.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }

  function resend(el) {
    // Re-fire the send action as a synthetic (untrusted) event — our own
    // listeners below ignore untrusted events, so this won't loop.
    setTimeout(() => {
      const sendBtn = SEND_BUTTON_SELECTORS.map((s) => document.querySelector(s)).find(Boolean);
      if (sendBtn && !sendBtn.disabled) {
        sendBtn.click();
        return;
      }
      el.dispatchEvent(
        new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true, cancelable: true })
      );
    }, 60);
  }

  function intercept(el) {
    if (!limitEnabled()) return false;
    const original = getText(el);
    if (!original || !original.trim()) return false;
    const modified = applyWordLimit(original, maxWords());
    if (modified === original) return false; // nothing to change, let it send normally
    setComposerText(el, modified);
    resend(el);
    return true; // we handled sending ourselves
  }

  document.addEventListener(
    'keydown',
    (e) => {
      if (!e.isTrusted) return;
      if (e.key !== 'Enter' || e.shiftKey) return;
      const el = findComposer(e.target);
      if (!el) return;
      if (intercept(el)) {
        e.preventDefault();
        e.stopImmediatePropagation();
      }
    },
    true
  );

  document.addEventListener(
    'click',
    (e) => {
      if (!e.isTrusted) return;
      const btn = SEND_BUTTON_SELECTORS.map((s) => e.target.closest(s)).find(Boolean);
      if (!btn) return;
      const el = findComposer(null);
      if (!el) return;
      if (intercept(el)) {
        e.preventDefault();
        e.stopImmediatePropagation();
      }
    },
    true
  );
})();
