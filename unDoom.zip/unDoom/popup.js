// ========== unDoom POPUP ==========

const DEFAULT_STATE = {
  masterEnabled: false,
  focusLock: true,
  youtube: {
    enabled: true,
    hideShorts: true,
    hideHomeRecommendations: true,
    hideRecommendedVideos: true,
    hideExploreTrending: true,
    hideComments: true,
    hideEndScreen: true,
    reduceSidebar: true,
    studyOnly: false,
    studyChannels: [],
  },
  telegram: {
    enabled: true,
    hideStories: false,
    hideSuggestedChannels: false,
    reduceDiscovery: false,
    reduceChatList: false,
    hideUnrelated: false,
    groupsOnly: false,
    studySources: ['Physics', 'Chemistry'],
  },
  security: {
    adShield: true,
    popupShield: true,
    phishingShield: true,
  },
  session: null,
  stats: {
    today: { protectedTime: 0, blocked: 0, sessions: 0, focusScore: 100 },
  },
};

let state = { ...DEFAULT_STATE };
let tickInterval = null;

// ========== LOAD STATE ==========
chrome.storage.local.get(['undoom'], (result) => {
  if (result.undoom) {
    state = { ...DEFAULT_STATE, ...result.undoom };
  }
  render();
  startTick();
});

// ========== SAVE STATE ==========
function save() {
  chrome.storage.local.set({ undoom: state });
}

// ========== RENDER ==========
function render() {
  const headerDot = document.getElementById('headerDot');
  const headerStatus = document.getElementById('headerStatus');
  if (!state.masterEnabled) {
    headerDot.className = 'dot dot-offline';
    headerStatus.textContent = 'OFFLINE';
  } else if (state.session && state.session.paused) {
    headerDot.className = 'dot dot-paused';
    headerStatus.textContent = 'PAUSED';
  } else {
    headerDot.className = 'dot dot-active';
    headerStatus.textContent = 'READY';
  }

  const mainDot = document.getElementById('mainDot');
  const mainStatus = document.getElementById('mainStatus');
  if (!state.masterEnabled) {
    mainDot.className = 'dot dot-offline';
    mainStatus.textContent = 'SYSTEM OFFLINE';
    mainStatus.className = 'status-text offline';
  } else if (state.session && state.session.paused) {
    mainDot.className = 'dot dot-paused';
    mainStatus.textContent = 'FOCUS PAUSED';
    mainStatus.className = 'status-text paused';
  } else {
    mainDot.className = 'dot dot-active';
    mainStatus.textContent = 'PROTECTION ACTIVE';
    mainStatus.className = 'status-text active';
  }

  document.querySelectorAll('#screen-youtube .toggle[data-key]').forEach(el => {
    const key = el.dataset.key;
    const val = state.youtube[key];
    el.classList.toggle('on', val);
    el.querySelector('.check').textContent = val ? '[✓]' : '[ ]';
  });

  document.querySelectorAll('#screen-telegram .toggle[data-key]').forEach(el => {
    const key = el.dataset.key;
    const val = state.telegram[key];
    el.classList.toggle('on', val);
    el.querySelector('.check').textContent = val ? '[✓]' : '[ ]';
  });

  document.querySelectorAll('#screen-telegram .toggle[data-source]').forEach(el => {
    const src = el.dataset.source;
    const val = state.telegram.studySources.includes(src);
    el.classList.toggle('on', val);
    el.querySelector('.check').textContent = val ? '[✓]' : '[ ]';
  });

  document.querySelectorAll('#screen-security .toggle[data-sec]').forEach(el => {
    const key = el.dataset.sec;
    const val = state.security[key];
    el.classList.toggle('on', val);
    el.querySelector('.check').textContent = val ? '[✓]' : '[ ]';
  });

  const focusDot = document.getElementById('focusDot');
  const focusStatus = document.getElementById('focusStatus');
  const toggleMaster = document.getElementById('toggleMaster');
  if (state.masterEnabled) {
    focusDot.className = 'dot dot-active';
    focusStatus.textContent = 'ACTIVE';
    focusStatus.className = 'status-text active';
    toggleMaster.textContent = '[ ON ]';
    toggleMaster.classList.add('primary');
  } else {
    focusDot.className = 'dot dot-offline';
    focusStatus.textContent = 'OFFLINE';
    focusStatus.className = 'status-text offline';
    toggleMaster.textContent = '[ OFF ]';
    toggleMaster.classList.remove('primary');
  }

  const flToggle = document.getElementById('focusLockToggle');
  if (flToggle) {
    flToggle.classList.toggle('on', state.focusLock);
    flToggle.querySelector('.check').textContent = state.focusLock ? '[✓]' : '[ ]';
  }
}

// ========== TICK ==========
function startTick() {
  if (tickInterval) clearInterval(tickInterval);
  tickInterval = setInterval(() => {
    if (state.session && !state.session.paused && !state.session.endTime) {
      const elapsed = Math.floor((Date.now() - state.session.startTime) / 1000);
      const el = document.getElementById('sessionTime');
      if (el) el.textContent = formatTime(elapsed);
    }
  }, 1000);
}

function formatTime(s) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
}

// ========== NAVIGATION ==========
document.querySelectorAll('.nav button').forEach(btn => {
  btn.addEventListener('click', () => {
    const screen = btn.dataset.screen;
    document.querySelectorAll('.nav button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById('screen-' + screen).classList.add('active');
  });
});

// ========== YOUTUBE TOGGLES ==========
document.querySelectorAll('#screen-youtube .toggle[data-key]').forEach(el => {
  el.addEventListener('click', () => {
    const key = el.dataset.key;
    state.youtube[key] = !state.youtube[key];
    save();
    render();
  });
});

// ========== TELEGRAM TOGGLES ==========
document.querySelectorAll('#screen-telegram .toggle[data-key]').forEach(el => {
  el.addEventListener('click', () => {
    const key = el.dataset.key;
    state.telegram[key] = !state.telegram[key];
    save();
    render();
  });
});

// ========== TELEGRAM STUDY SOURCES ==========
document.querySelectorAll('#screen-telegram .toggle[data-source]').forEach(el => {
  el.addEventListener('click', () => {
    const src = el.dataset.source;
    const idx = state.telegram.studySources.indexOf(src);
    if (idx >= 0) state.telegram.studySources.splice(idx, 1);
    else state.telegram.studySources.push(src);
    save();
    render();
  });
});

// ========== SECURITY TOGGLES ==========
document.querySelectorAll('#screen-security .toggle[data-sec]').forEach(el => {
  el.addEventListener('click', () => {
    const key = el.dataset.sec;
    state.security[key] = !state.security[key];
    save();
    render();
  });
});

// ========== MASTER TOGGLE (CHALLENGE ONLY ON DISABLE) ==========
document.getElementById('toggleMaster').addEventListener('click', () => {
  
  // Agar master OFF hai → DIRECT ON (koi challenge nahi)
  if (!state.masterEnabled) {
    state.masterEnabled = true;
    save();
    render();
    reloadTabs();
    return;
  }

  // Agar master ON hai → user OFF karna chahta hai
  if (state.masterEnabled) {
    if (state.focusLock) {
      // Focus Lock ON → Challenge dikhao
      showFocusLockChallenge(() => {
        state.masterEnabled = false;
        save();
        render();
        reloadTabs();
      });
    } else {
      // Focus Lock OFF → Direct OFF
      state.masterEnabled = false;
      save();
      render();
      reloadTabs();
    }
  }
});

function reloadTabs() {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(t => {
      if (t.url && !t.url.startsWith('chrome://')) {
        chrome.tabs.reload(t.id);
      }
    });
  });
}

// ========== FOCUS LOCK TOGGLE ==========
const flToggle = document.getElementById('focusLockToggle');
if (flToggle) {
  flToggle.addEventListener('click', () => {
    state.focusLock = !state.focusLock;
    save();
    render();
  });
}

// ========== FOCUS LOCK CHALLENGE (SHORT PASSAGE) ==========
function showFocusLockChallenge(onSuccess) {
  const passages = [
    'Focus is the art of knowing what to ignore. Discipline is the bridge between goals and accomplishment. Stay hard.',
    'The obstacle is the way. Comfort is the enemy of progress. Do it now, because later becomes never.',
    'You do not rise to the level of your goals. You fall to the level of your systems. Build better systems.',
    'Motivation is garbage. Discipline is everything. Small disciplines repeated daily lead to great achievements.',
    'The mind is the athlete. The body just follows. Focus is a form of self-respect. A distracted mind is a wasted mind.'
  ];

  const passage = passages[Math.floor(Math.random() * passages.length)];

  const overlay = document.createElement('div');
  overlay.id = 'focus-lock-overlay';
  overlay.style.cssText = `
    position: fixed;
    inset: 0;
    background: #0A0B0D;
    z-index: 999999999;
    padding: 40px;
    display: flex;
    flex-direction: column;
    font-family: 'Segoe UI', system-ui, Arial, sans-serif;
    overflow-y: auto;
  `;

  overlay.innerHTML = `
    <div style="max-width: 900px; margin: 0 auto; width: 100%;">
      
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;padding-bottom:15px;border-bottom:1px solid #1F2329;">
        <div>
          <div style="font-family:Consolas,monospace;font-size:12px;color:#00E5A0;letter-spacing:2px;margin-bottom:4px;">
            ┌ FOCUS LOCK ACTIVE
          </div>
          <div style="font-family:Consolas,monospace;font-size:10px;color:#5A6169;letter-spacing:1px;">
            // VERIFICATION PROTOCOL REQUIRED
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:8px;">
          <span style="width:8px;height:8px;border-radius:50%;background:#FFB84D;box-shadow:0 0 8px #FFB84D;"></span>
          <span style="font-family:Consolas,monospace;font-size:11px;color:#FFB84D;letter-spacing:1px;">LOCKED</span>
        </div>
      </div>

      <div style="font-family:Consolas,monospace;font-size:12px;color:#8B929E;line-height:1.7;margin-bottom:20px;">
        &gt; DISABLE REQUEST DETECTED<br>
        &gt; Complete verification protocol to release the focus lock.<br>
        &gt; Type the passage below accurately to proceed.
      </div>

      <div id="challengeText" style="
        background: #111316;
        border: 1px solid #1F2329;
        border-radius: 8px;
        padding: 30px;
        font-family: 'Consolas', monospace;
        font-size: 20px;
        line-height: 1.9;
        color: #8B929E;
        letter-spacing: 0.3px;
        margin-bottom: 20px;
        user-select: none;
      "></div>

      <textarea id="challengeInput" 
        placeholder="Start typing the passage here..."
        autocomplete="off"
        spellcheck="false"
        style="
          width: 100%;
          min-height: 100px;
          background: #111316;
          border: 1px solid #1F2329;
          border-radius: 8px;
          padding: 20px;
          color: #E8EAED;
          font-family: 'Consolas', monospace;
          font-size: 16px;
          line-height: 1.7;
          outline: none;
          resize: vertical;
          margin-bottom: 20px;
        "></textarea>

      <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; margin-bottom: 20px;">
        <div style="background:#111316;border:1px solid #1F2329;border-radius:6px;padding:12px;text-align:center;">
          <div style="font-family:Consolas,monospace;font-size:10px;color:#5A6169;letter-spacing:1px;margin-bottom:4px;">ACCURACY</div>
          <div id="chAccuracy" style="font-family:Consolas,monospace;font-size:24px;color:#00E5A0;font-weight:bold;">0%</div>
        </div>
        <div style="background:#111316;border:1px solid #1F2329;border-radius:6px;padding:12px;text-align:center;">
          <div style="font-family:Consolas,monospace;font-size:10px;color:#5A6169;letter-spacing:1px;margin-bottom:4px;">PROGRESS</div>
          <div id="chProgress" style="font-family:Consolas,monospace;font-size:24px;color:#E8EAED;font-weight:bold;">0 / 0</div>
        </div>
        <div style="background:#111316;border:1px solid #1F2329;border-radius:6px;padding:12px;text-align:center;">
          <div style="font-family:Consolas,monospace;font-size:10px;color:#5A6169;letter-spacing:1px;margin-bottom:4px;">ERRORS</div>
          <div id="chErrors" style="font-family:Consolas,monospace;font-size:24px;color:#FF4D4D;font-weight:bold;">0</div>
        </div>
      </div>

      <div style="display:flex;gap:10px;">
        <button id="chSubmit" disabled style="
          flex: 2;
          padding: 16px;
          border-radius: 6px;
          border: 1px solid rgba(0,229,160,0.4);
          background: rgba(0,229,160,0.1);
          color: #00E5A0;
          font-family: Consolas, monospace;
          font-size: 13px;
          letter-spacing: 2px;
          cursor: not-allowed;
          opacity: 0.4;
        ">[ DISABLE PROTOCOL ]</button>
        <button id="chCancel" style="
          flex: 1;
          padding: 16px;
          border-radius: 6px;
          border: 1px solid #2A2F36;
          background: transparent;
          color: #8B929E;
          font-family: Consolas, monospace;
          font-size: 13px;
          letter-spacing: 2px;
          cursor: pointer;
        ">[ CANCEL ]</button>
      </div>

      <div style="font-family:Consolas,monospace;font-size:10px;color:#5A6169;margin-top:15px;text-align:center;">
        &gt; 95% accuracy required to complete verification
      </div>

    </div>
  `;

  document.body.appendChild(overlay);

  const challengeText = document.getElementById('challengeText');
  const input = document.getElementById('challengeInput');
  const accuracy = document.getElementById('chAccuracy');
  const progress = document.getElementById('chProgress');
  const errors = document.getElementById('chErrors');
  const submit = document.getElementById('chSubmit');
  const cancel = document.getElementById('chCancel');

  let errorCount = 0;
  let lastLength = 0;

  function renderChallenge() {
    const typed = input.value;
    let html = '';
    for (let i = 0; i < passage.length; i++) {
      if (i < typed.length) {
        if (typed[i] === passage[i]) {
          html += `<span style="color:#00E5A0;">${passage[i]}</span>`;
        } else {
          html += `<span style="color:#FF4D4D;background:rgba(255,77,77,0.15);">${passage[i]}</span>`;
        }
      } else {
        html += `<span>${passage[i]}</span>`;
      }
    }
    challengeText.innerHTML = html;

    let correct = 0;
    for (let i = 0; i < typed.length; i++) {
      if (typed[i] === passage[i]) correct++;
    }
    const acc = typed.length > 0 ? Math.round((correct / typed.length) * 100) : 0;
    accuracy.textContent = acc + '%';
    accuracy.style.color = acc >= 95 ? '#00E5A0' : acc >= 80 ? '#FFB84D' : '#FF4D4D';
    
    progress.textContent = `${typed.length} / ${passage.length}`;

    if (typed.length > lastLength) {
      const i = typed.length - 1;
      if (typed[i] !== passage[i]) errorCount++;
    }
    lastLength = typed.length;
    errors.textContent = errorCount;

    const complete = typed.length >= passage.length;
    const passed = complete && acc >= 95;

    if (passed) {
      submit.disabled = false;
      submit.style.opacity = '1';
      submit.style.cursor = 'pointer';
      submit.style.background = 'rgba(0,229,160,0.2)';
      submit.style.borderColor = '#00E5A0';
    } else {
      submit.disabled = true;
      submit.style.opacity = '0.4';
      submit.style.cursor = 'not-allowed';
      submit.style.background = 'rgba(0,229,160,0.1)';
      submit.style.borderColor = 'rgba(0,229,160,0.4)';
    }
  }

  input.addEventListener('input', renderChallenge);
  input.addEventListener('paste', (e) => e.preventDefault());
  input.addEventListener('drop', (e) => e.preventDefault());

  renderChallenge();
  input.focus();

  submit.addEventListener('click', () => {
    overlay.remove();
    onSuccess();
  });

  cancel.addEventListener('click', () => {
    overlay.remove();
  });

  overlay.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') e.preventDefault();
  });
}

console.log('[unDoom Popup] Loaded - Challenge only on disable');