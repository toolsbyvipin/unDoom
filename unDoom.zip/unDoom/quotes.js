const quotes = [
  "Discipline is choosing what you want most over what you want now.",
  "Every minute you protect from distraction is a minute invested in who you're becoming.",
  "Focus is a muscle — the more you guard it, the stronger it gets.",
  "You don't need more time, you need fewer distractions.",
  "Small, uninterrupted efforts compound into big results.",
  "The scroll can wait. Your goals can't.",
  "Stay on the path — future you is counting on today's focus."
];

const quoteEl = document.getElementById('quoteText');
let quoteIndex = 0;

function showQuote(index) {
  quoteEl.classList.remove('visible');
  setTimeout(() => {
    quoteEl.textContent = quotes[index];
    quoteEl.classList.add('visible');
  }, 300);
}

showQuote(quoteIndex);
setInterval(() => {
  quoteIndex = (quoteIndex + 1) % quotes.length;
  showQuote(quoteIndex);
}, 8000);
