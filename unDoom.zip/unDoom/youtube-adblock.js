// ========== unDoom — YOUTUBE PROTOCOL + ENHANCED AD BLOCKER ==========
// Fix: previously youtube.css rules were unconditional (always on, even
// with the extension "OFF"). Now every rule is gated behind an <html>
// class that this script maintains from live storage state, so toggles
// in the popup — and the master ON/OFF switch — actually take effect.

(function () {
  if (!window.location.hostname.includes('youtube.com')) return;

  let state = null;

  function loadState(cb) {
    chrome.storage.local.get(['undoom'], (r) => cb(r.undoom || null));
  }

  function applyFlags() {
    const masterOn = !!(state && state.masterEnabled);
    const yt = (state && state.youtube) || {};
    const on = (key) => masterOn && yt.enabled !== false && yt[key] !== false;
    const html = document.documentElement;

    html.classList.toggle('undoom-yt-active', masterOn && yt.enabled !== false);
    html.classList.toggle('undoom-hide-shorts', on('hideShorts'));
    html.classList.toggle('undoom-hide-home', on('hideHomeRecommendations'));
    html.classList.toggle('undoom-hide-recommended', on('hideRecommendedVideos'));
    html.classList.toggle('undoom-hide-explore', on('hideExploreTrending'));
    html.classList.toggle('undoom-hide-comments', on('hideComments'));
    html.classList.toggle('undoom-hide-endscreen', on('hideEndScreen'));
    html.classList.toggle('undoom-reduce-sidebar', on('reduceSidebar'));
  }

  loadState((s) => { state = s; applyFlags(); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.undoom) return;
    state = changes.undoom.newValue;
    applyFlags();
  });

  // ========== ENHANCED AD BLOCKER ==========
  // rules.json handles the network layer (blocks ad-serving domains and
  // YouTube's own ad-tracking endpoints). This DOM layer is the backup:
  // it removes ad containers the network layer can't see, auto-clicks the
  // skip button the instant it appears, and fast-forwards through
  // unskippable video ads so you never sit through one.

  const AD_CONTAINER_SELECTORS = [
    '.video-ads', '.ytp-ad-module', '.ytp-ad-overlay-container',
    'ytd-display-ad-renderer', 'ytd-promoted-sparkles-web-renderer',
    'ytd-promoted-video-renderer', 'ytd-ad-slot-renderer',
    '#player-ads', 'ytd-companion-slot-renderer', 'ytd-action-companion-ad-renderer',
    'ytd-in-feed-ad-layout-renderer', 'ytd-banner-promo-renderer',
    'ytd-statement-banner-renderer', '#masthead-ad',
    'tp-yt-paper-dialog ytd-mealbar-promo-renderer'
  ];

  const SKIP_BUTTON_SELECTORS = [
    '.ytp-ad-skip-button', '.ytp-skip-ad-button',
    '.ytp-ad-skip-button-modern', '.ytp-ad-skip-button-container button',
    'button.ytp-ad-overlay-close-button'
  ];

  function adBlockerEnabled() {
    return !!(state && state.youtube && state.youtube.enabled !== false && state.security && state.security.adShield !== false)
      // Default true even before state loads / if security block is missing:
      || !state;
  }

  function cleanAdContainers() {
    AD_CONTAINER_SELECTORS.forEach((sel) => {
      document.querySelectorAll(sel).forEach((el) => el.remove());
    });
  }

  function clickSkipIfPresent() {
    for (const sel of SKIP_BUTTON_SELECTORS) {
      const btn = document.querySelector(sel);
      if (btn) {
        btn.click();
        return true;
      }
    }
    return false;
  }

  function fastForwardVideoAd() {
    const player = document.querySelector('.html5-video-player');
    const video = document.querySelector('video');
    if (!player || !video) return;
    const adShowing =
      player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting');
    if (adShowing && isFinite(video.duration) && video.duration > 0) {
      try {
        video.currentTime = video.duration;
      } catch (e) {
        /* ignore — video may not be seekable yet */
      }
    }
  }

  function adTick() {
    if (!adBlockerEnabled()) return;
    cleanAdContainers();
    clickSkipIfPresent();
    fastForwardVideoAd();
  }

  function start() {
    adTick();
    new MutationObserver(adTick).observe(document.documentElement, { childList: true, subtree: true });
    // Backstop poll — some ad UI updates don't trigger a mutation we catch (e.g. countdown text only).
    setInterval(adTick, 500);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
